<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <title>Nure's Website</title>
    <style>
        @keyframes spinAnimation {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }

        .spinning-title {
            animation: spinAnimation 2s linear; 
        }

        body {
            font-family: Arial, sans-serif;
        }

        ol {
            font-size: 22.5px; 
        }

        .content {
            margin-left: 220px;
            padding: 20px;
        }
        a:link {
        color: green;
        background-color: transparent;
        text-decoration: none;
        }

        a:visited {
        color: pink;
        background-color: transparent;
        text-decoration: none;
        }

        a:hover {
        color: red;
        background-color: transparent;
        text-decoration: underline;
        }

        a:active {
        color: blue;
        background-color: transparent;
        text-decoration: underline;
        }

    </style>
</head>
<body class="w3-light-gray">
    <h1 class="w3-margin w3-padding w3-border w3-border-black w3-light-blue 
    w3-center w3-text-black spinning-title">Best Video Game Characters</h1>

    <div>
        <a href="games.html" class="w3-margin">If you are interested in other video games</a>
    </div>
    <div>
        <a href="reviews.php" class="w3-margin">If you want to leave a review</a>
    </div>
    <div>
        <a href="logout.php" class="w3-center w3-right-align w3-margin">Logout</a>
    </div>

    <ol class="top5 w3-center">
        <li>
            <div class="Kiryu">
                <h3>Kiryu Kazuma</h3>
                <p>The main character of the Yakuza Franchise.</p>
            </div>
            <img src="kiryu.webp" alt="kiryu">
        </li>
        
        <li>
            <div class="taichi">
                <h3>Taichi Suzuki</h3>
                <p>Greatest Taxi Driver in All of Japan</p>
            </div>
            <img src="taichi.webp" alt="taichi">
        <li>
            <div class="joryu">
                <h3>Joryu</h3>
                <p>Secret Agent of the Daidoji Faction</p>
            </div>
            <img src="joryu.webp" alt="joryu">
        </li>
        <li>
            <div class="samurai">
                <h3>Sakamoto Ryoma</h3>
                <p>A Ronin From Tosa Looking to Avenge the Murder of his Adoptive Father, Yoshida Toyo.</p>
            </div>
            <img width="800px" height="500px" src="sakaomto.jpeg" alt="ryoma">
        </li>
    </ol>
    <h1 class="w3-center"> Thank you for reading! For more information on other characters,
         
    </h1> 
    <h1 class="w3-center"> please visit
    <a href="https://yakuza.fandom.com/wiki/Category:Characters" target="_blank" >this link here!</a>
    </h1>
    
    <br>
    <br>

    <footer class="w3-center"> Nure Sabri 2023</footer>
</body>
</html>