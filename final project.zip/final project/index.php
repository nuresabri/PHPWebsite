<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <title>User Login</title>
</head>
<body class="w3-light-gray">
        <h1 class="w3-margin w3-padding w3-border w3-border-black w3-light-blue 
        w3-center w3-text-black">User Login</h1>

        <?php
            include("config.php");
            session_start();
            
            if($_SERVER["REQUEST_METHOD"] == "POST") {
            
              $myusername = mysqli_real_escape_string($db,$_POST['username']);
              $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
            
              $sql = "SELECT id FROM admin WHERE username = '$myusername' and passcode = '$mypassword'";
              $result = mysqli_query($db,$sql);
              $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
              $active = $row['active'];
            
              $count = mysqli_num_rows($result);
                        
              if($count == 1) {
                 session_register("username");
                 $_SESSION['login_user'] = $myusername;
            
                 header("location: page.php");
              }
              else {
                 $error = "Your Login Name or Password is invalid";
                }
             }
        ?>

    <form action="login.php" method="post">
        <p class="w3-center">
            <label class="w3-center w3-margin" for="username">Username:</label>
            <input class="w3-center"type="text" id="username" name="username" required><br>

            <br>

            <label class="w3-center w3-margin" for="password">Password:</label>
            <input class="w3-center"type="password" id="password" name="password" required><br>

            <button class="w3-hoverable w3-margin" type="submit">Login</button>
        </p>
    </form>
    <form method="get" action="registration.php">
        <p class="w3-center">
            <button class="w3-hoverable w3-margin" type="submit">Register</button>
        </p>
    </form>
    <form method-"get" action="adminlog.php">
        <p class="w3-center">
            <button type="submit">Admin Page</button>
        </p>
</form>
</body>
</html>