<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <title>User Registration</title>
</head>
<body class="w3-light-gray">
        <h1 class="w3-margin w3-padding w3-border w3-border-black w3-light-blue 
        w3-center w3-text-black">User Registration</h1>
    
    <?php
    include 'config.php';

    if (!empty($userStatus)) {
        echo "<p>$userStatus</p>";
    }
    $conn->close();
    ?>

    <form action="server.php" method="POST">
      <p class="w3-center">
        <label for="username">Username:</label>
            <input type="text" name="username" required>

            <label for="password">Password:</label>
            <input type="password" name="password" required>

            <input type="submit" value="Register">
      </p>
    </form>


</body>
</html>