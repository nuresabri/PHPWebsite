<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body class="w3-light-gray">
    <?php
    $dsn = 'mysql:host=localhost;dbname=project';
    $username_db = "root";
    $password_db = "root";

    try {
        $pdo = new PDO($dsn, $username_db, $password_db);
    } catch (PDOException $e) {
        die("Connection error" . $e->getMessage());
    }

    $game_rec = $_POST['game_rec'];


    $stmt1 = $pdo->prepare("SELECT username FROM registered_table LIMIT 1");
    $stmt1->execute();
    $result = $stmt1->fetch(PDO::FETCH_ASSOC);

    //updates game_recs w following information
    $sql = "INSERT INTO game_recs (username, game_rec) VALUES (:username, :game_rec)";
    $statement = $pdo->prepare($sql);

    // Bind parameters
    $statement->bindParam(':username', $result['username']);
    $statement->bindParam(':game_rec', $game_rec);

    try {
        if ($statement->execute()) {
            echo "<h3 class='w3-margin w3-padding w3-border w3-border-black w3-light-blue 
                w3-center w3-text-black'>Thank you! You have successfully submitted your recommendation!</h3>";
            echo "<p class='w3-center'><img width='500px' hieght='350px' src='kiryuhappy.webp'>";
            echo "<form method='get' action='index.php'>
                <p class='w3-center'>
                <button class='w3-hoverable w3-margin' type='submit'>Login</button>
                </p>
            </form>";
        } else {
            echo "<h3 class='w3-center w3-red'>Review submission failed. Please try again later.</h3>";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    $pdo = null;
    ?>
</body>

</html>