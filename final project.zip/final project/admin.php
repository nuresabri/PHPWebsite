<?php

include("config.php");

$dsn = 'mysql:host=localhost;dbname=project';
$username_db = "root";
$password_db = "root";

try {
    $pdo = new PDO($dsn, $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

function addUser($username, $password) {
    global $pdo;
    $sql = "INSERT INTO registered_table (username, password) VALUES (:username, :password)";
    $statement = $pdo->prepare($sql);
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    $statement->bindParam(':username', $username);
    $statement->bindParam(':password', $hashedPassword);
    $statement->execute();
}


function updateUser($oldUsername, $newUsername) {
    global $pdo;
    $sql = "UPDATE registered_table SET username = :newUsername WHERE username = :oldUsername";
    $statement = $pdo->prepare($sql);
    $statement->bindParam(':oldUsername', $oldUsername);
    $statement->bindParam(':newUsername', $newUsername);
    $statement->execute();
}

function deleteUser($username) {
    global $pdo;
    $sql = "DELETE FROM registered_table WHERE username = :username";
    $statement = $pdo->prepare($sql);
    $statement->bindParam(':username', $username);
    $statement->execute();
}

function getAllUsers() {
    global $pdo;
    $sql = "SELECT * FROM registered_table";
    $statement = $pdo->prepare($sql);
    $statement->execute();
    return $statement->fetchAll(PDO::FETCH_ASSOC);
}

session_start();
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header('Location: login.php');
    exit;
}

// CRUD operations
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Add a user
    if (isset($_POST['addUser'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        addUser($username, $password);
    }

    // Update a user
    if (isset($_POST['updateUser'])) {
        $username = $_POST['username'];
        $newUsername = $_POST['newUsername'];
        updateUser($username, $newUsername);
    }

    // Delete a user
    if (isset($_POST['deleteUser'])) {
        $username = $_POST['username'];
        deleteUser($username);
    }
}

$users = getAllUsers();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <title>Admin</title>
</head>
<body>

<h1 class="w3-light-blue w3-center w3-border w3-black-border">Welcome to the Admin's Page</h1>

<form method="post" action="admin.php">
   <p class="w3-center"> 
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required>
    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required>
    <button type="submit" name="addUser">Add User</button>
</p>
</form>

<h2 class="w3-center">Admin Powers</h2>
<table border="1" class="w3-center">
    <tr>
        <th class="w3-center">Username</th>
        <th class="w3-center">Action</th>
    </tr>
    <?php foreach ($users as $user) : ?>
        <tr w3-align="center">
            <td><?php echo $user['username']; ?></td>
            <td>
                <form method="post" action="admin.php" class="w3-center">
                    <input type="hidden" name="username" value="<?php echo $user['username']; ?>">
                    <label for="newUsername">New Username:</label>
                    <input type="text" id="newUsername_<?php echo $user['username']; ?>" name="newUsername" required>
                    <button type="submit" name="updateUser">Update User</button>
                </form>
                <form method="post" action="admin.php" class="w3-center">
                    <input type="hidden" name="username" value="<?php echo $user['username']; ?>">
                    <button type="submit" name="deleteUser">Delete User</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<form method='get' action='index.php'><p class='w3-center'>
    <button class='w3-hoverable w3-margin' type='submit'>Login</button><p></form>

</body>
</html>
