<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body class="w3-light-gray">
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if (strlen($password) < 7 || strlen($password) > 15 || !preg_match('/\d/', $password)) {
            echo "<h3 class='w3-center w3-red'>Password must be between 7 and 15 characters 
            and contain at least one number.</h3>";
            echo "<p class='w3-center'><img src=error.png></p>";
            echo "<form method='get' action='registration.php'>
            <p class='w3-center'>
                <button class='w3-hoverable w3-margin' type='submit'>Register</button>
            </p>
        </form>";
            exit();
        }

        $dsn = 'mysql:host=localhost;dbname=project';
        $username_db = "root";
        $password_db = "root";

        try {
            $pdo = new PDO($dsn, $username_db, $password_db);
        } catch (PDOException $e) {
            die("Connection error" . $e->getMessage());
        }

        // this is to see if someone already has username
        $checkUsernameQuery = "SELECT * FROM registered_table WHERE username = ?";
        $checkUsernameStmt = $pdo->prepare($checkUsernameQuery);
        $checkUsernameStmt->execute([$username]);

        if ($checkUsernameStmt->fetch()) {
            // if someone has username already
            echo "<h3 class='w3-center w3-red'>Username already exists. Please choose a different username.</h3>";
            echo "<p class='w3-center'><img src=error.png></p>";
            echo "<form method='get' action='registration.php'>
            <p class='w3-center'>
                <button class='w3-hoverable w3-margin' type='submit'>Register</button>
            </p>
        </form>";
        } else {
            // adds new user into db
            $sql = "INSERT INTO registered_table(username, password) VALUES(:username, :password)";
            $statement = $pdo->prepare($sql);

            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

            $statement->bindParam(':username', $username);
            $statement->bindParam(':password', $hashedPassword);

            if ($statement->execute()) {
            echo "<h3 class='w3-margin w3-padding w3-border w3-border-black w3-light-blue 
                w3-center w3-text-black'>You are successfully registered</h3>";
            echo "<form method='get' action='index.php'>
                <p class='w3-center'>
                <button class='w3-hoverable w3-margin' type='submit'>Login</button>
                </p>
            </form>";
            } else {
                echo "<h3 class='w3-center w3-red'>Registration failed. Please try again later.</h3>";
            }
        }

        $pdo = null;
    }
    ?>
</body>

</html>
