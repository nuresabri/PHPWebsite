<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    
    if ($username ==='admin' && $password === 'admin123') {
        session_start();
        $_SESSION['is_admin'] = true;

        header('Location: admin.php');
        exit;
    } else {
        
        echo "<h3 class='w3-center w3-red'>Invalid username or password.</h3>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <title>Admin Login</title>
</head>
<body>

<h1 class="w3-center w3-light-blue w3-border w3-border-black">Admin Login</h1>
<form method="post">
    <p class="w3-center">
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required>
    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required>
    <button type="submit">Login</button>
    </p>
</form>

</body>
</html>