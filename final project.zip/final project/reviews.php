<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <title>Game Reviews</title>
</head>

<body class="w3-light-gray">
    <?php
    session_start();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = isset($_SESSION['username']) ? $_SESSION['username'] : null;
        $gameName = $_POST['game_name'];
        $reviewText = $_POST['review_text'];

        if (!$username) {
            header("Location: index.php");
            exit();
        }

        $dsn = 'mysql:host=localhost;dbname=project';
        $username_db = "root";
        $password_db = "root";

        try {
            $pdo = new PDO($dsn, $username_db, $password_db);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // this updates the game_reviews table with username, game name, and review
            $sql = "INSERT INTO game_reviews (username, game_name, review_text) VALUES (?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$username, $gameName, $reviewText]);

            echo "<h3 class='w3-margin w3-padding w3-border w3-border-black w3-light-blue 
                w3-center w3-text-black'>Review successfully added!</h3>";
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }

        $pdo = null;
    }
    ?>

    <!-- this is the review form itself -->
    <div class="w3-container w3-padding">
        <h2 class="w3-center w3-pale-red w3-border w3-border-black">Submit a Game Review</h2>
        <form method="post" action="subrev.php">
            <p class="w3-center"><label for="game_name">Game Name:</label></p>
            <p class="w3-center"><input type="text" id="game_name" name="game_name" required></p>

            <p class="w3-center"><label for="review_text">Review:</label></p>
            <p class="w3-center"><textarea id="review_text" name="review_text" rows="4" required></textarea></p>

            <p class="w3-center"><button type="submit">Submit Review</button></p>
        </form>
    </div>
    <div class="w3-container w3-padding">
        <h2 class="w3-center w3-pale-red w3-border w3-border-black">Submit a Game Recommendation</h2>
        <form method="post" action="subrating.php">
        <p class="w3-center"><label for="game_rec">Game Name:</label></p>
        <p class="w3-center"><input type="text" id="game_rec" name="game_rec" required></p>

        <p class="w3-center"><button type="submit">Submit Recommendation</button></p>
        </form>
    </div>
</body>

</html>
