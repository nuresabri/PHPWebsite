<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <title>User Login</title>
</head>
<body class="w3-light-gray">

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $dsn = 'mysql:host=localhost;dbname=project';
    $username_db = "root";
    $password_db = "root";

    try {
        $pdo = new PDO($dsn, $username_db, $password_db);
    } catch (PDOException $e) {
        die("Connection error: " . $e->getMessage());
    }

    function user_exists($username, $password)
    {
        global $pdo;

        $sql = "SELECT password FROM registered_table WHERE username=?";
        $statement = $pdo->prepare($sql);
        $statement->execute([$username]);

        $info = $statement->fetch();

        if ($info) {
            $hashedPassword = $info['password'];

            if (password_verify($password, $hashedPassword)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    $user_exists_bool = user_exists($username, $password);

    if ($user_exists_bool) {
        header("Location: page.php");
        exit();
    } else {
        echo "<h1 class='w3-text-black w3-red w3-border w3-border-black w3-center'>
        Invalid username or password.</h1>";
        echo "<p class='w3-center'><img src=error.png></p>";
        echo "<form method='get' action='registration.php'>
            <p class='w3-center'>
                <button class='w3-hoverable w3-margin' type='submit'>Register</button>
            </p>
        </form>";
        echo "<form method='get' action='index.php'>
                <p class='w3-center'>
                <button class='w3-hoverable w3-margin' type='submit'>Login</button>
                </p>
            </form>";
    }

    $pdo = null;
}
?>