<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>

<?php
include("config.php");
session_start();

echo "<h1 class='w3-light-blue w3-center w3-text-black'>";
echo "You are successfully logged out";
echo '</h1>';
echo "<form method='get' action='index.php'><p class='w3-center'>
    <button class='w3-hoverable w3-margin' type='submit'>Login</button><p></form>";

session_destroy();
$_SESSION = array();
?>

</body>
</html>